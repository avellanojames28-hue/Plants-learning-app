package com.sibol.plantparts;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Locale;

/** Runs the lesson full-screen and gives it a cheerful native voice (WebView has no speechSynthesis). */
public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            tts.setLanguage(Locale.US);
            tts.setPitch(1.3f);        // brighter, happier voice
            tts.setSpeechRate(0.92f);  // a little slower for young listeners
            try {
                for (Voice v : tts.getVoices()) {
                    String n = v.getName().toLowerCase(Locale.ROOT);
                    if (v.getLocale().getLanguage().equals("en") && !v.isNetworkConnectionRequired()
                            && (n.contains("sfg") || n.contains("tpf") || n.contains("female"))) {
                        tts.setVoice(v);
                        break;
                    }
                }
            } catch (Exception ignored) { }
            ttsReady = true;
        });

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Speaker(), "AndroidTTS");
        web.setBackgroundColor(0xFFE3F3FA);
        setContentView(web);
        hideBars();
        web.loadUrl("file:///android_asset/index.html");
    }

    private void hideBars() {
        web.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideBars(); }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(location.hash&&location.hash!=='#home')?(go('home'),1):0", r -> {
            if (!"1".equals(r)) finish();
        });
    }

    @Override protected void onPause() { super.onPause(); if (tts != null) tts.stop(); }

    @Override protected void onDestroy() { if (tts != null) tts.shutdown(); super.onDestroy(); }

    class Speaker {
        @JavascriptInterface public void speak(String text) {
            if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "line");
        }
        @JavascriptInterface public void stop() { if (ttsReady) tts.stop(); }
    }
}
