# Plant Parts (Lesson 1) — Android app

Interactive "Parts of a Plant" lesson with Sibol the sprout, a cheerful voice, and S Pen drawing.

## Get the APK without installing anything (GitHub)
1. Make a free GitHub account and create a new repository.
2. Upload everything in this folder (keep the hidden `.github` folder).
3. Open the **Actions** tab — "Build APK" runs automatically (about 5 minutes).
4. Open the finished run, download **PlantParts-apk**, unzip it, and copy `app-debug.apk` to the phone.
5. On the S25 Ultra, tap the file and allow "Install unknown apps" for your file manager when asked.

## Or build with Android Studio
Open this folder in Android Studio, then **Build > Build App Bundle(s)/APK(s) > Build APK(s)**.

## Voice
The app uses the phone's text-to-speech. For the best voice: Settings > General management >
Text-to-speech > Preferred engine: **Speech Services by Google**, then download the US English voice.
